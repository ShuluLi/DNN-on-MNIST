#include "BP_OpenMP_Functions.h"

int main() {
    using namespace std::chrono;

    // Parameters
    int input_size = 784;
    int hidden1_size = 256;
    int hidden2_size = 128;
    int hidden3_size = 64;
    int output_size = 10;
    double learning_rate = 0.001;
    int batch_size = 20;
    int actual_epochs = 0;

    // Initialize weights
    std::vector<std::vector<double>> w1, w2, w3, w4;
    initialize_weights(w1, input_size, hidden1_size);
    initialize_weights(w2, hidden1_size, hidden2_size);
    initialize_weights(w3, hidden2_size, hidden3_size);
    initialize_weights(w4, hidden3_size, output_size);

    // Initialize biases
    std::vector<double> b1, b2, b3, b4;
    initialize_bias(b1, hidden1_size);
    initialize_bias(b2, hidden2_size);
    initialize_bias(b3, hidden3_size);
    initialize_bias(b4, output_size);

    // Data reading variables
    std::vector<std::vector<double>> all_images, all_labels;
    std::vector<std::vector<double>> train_images, train_labels;
    std::vector<std::vector<double>> validation_images, validation_labels;
    std::vector<std::vector<double>> test_images, test_labels;

    // Read data
    read_mnist_images("train-images.idx3-ubyte", all_images, 60000, 784);
    read_mnist_labels("train-labels.idx1-ubyte", all_labels, 60000, 10);

    // Split the training and validation sets
    split_train_val(all_images, all_labels, train_images, train_labels, validation_images, validation_labels);

    // Read test set
    read_mnist_images("t10k-images.idx3-ubyte", test_images, 10000, 784);
    read_mnist_labels("t10k-labels.idx1-ubyte", test_labels, 10000, 10);

    // Early stopping mechanism
    double best_val_accuracy = 0.0;
    int patience = 10;
    int patience_counter = 0;

    // Start timing
    auto start = high_resolution_clock::now();
    long long total_epoch_time = 0;
    long long total_training_time = 0;

    std::string result_file = "result.txt";

    for (int epoch = 0; epoch < 100; ++epoch) {
        auto epoch_start = high_resolution_clock::now();
        auto training_start = high_resolution_clock::now();

        double total_loss = 0.0;

        // Batch training
        int batch_count = 0;
#pragma omp parallel for schedule(static) reduction(+:total_loss)
        for (int batch_start = 0; batch_start < train_images.size(); batch_start += batch_size) {
            int batch_end = std::min(batch_start + batch_size, (int)train_images.size());
            batch_count++;

            // Initialize gradient accumulation variables
            std::vector<std::vector<double>> grad_w1(w1.size(), std::vector<double>(w1[0].size(), 0.0));
            std::vector<std::vector<double>> grad_w2(w2.size(), std::vector<double>(w2[0].size(), 0.0));
            std::vector<std::vector<double>> grad_w3(w3.size(), std::vector<double>(w3[0].size(), 0.0));
            std::vector<std::vector<double>> grad_w4(w4.size(), std::vector<double>(w4[0].size(), 0.0));
            std::vector<double> grad_b1(b1.size(), 0.0);
            std::vector<double> grad_b2(b2.size(), 0.0);
            std::vector<double> grad_b3(b3.size(), 0.0);
            std::vector<double> grad_b4(b4.size(), 0.0);

#pragma omp parallel for
            for (int i = batch_start; i < batch_end; ++i) {
                std::vector<double> hidden1(hidden1_size), hidden2(hidden2_size), hidden3(hidden3_size), output(output_size);

                // Forward pass
                forward_pass(train_images[i], hidden1, hidden2, hidden3, output, w1, w2, w3, w4, b1, b2, b3, b4);

                // Compute loss
                double loss = compute_loss(output, train_labels[i]);
#pragma omp atomic
                total_loss += loss;

                // Backward pass, accumulate gradients
                backward_pass_accumulate(train_images[i], hidden1, hidden2, hidden3, output, train_labels[i],
                                         grad_w1, grad_w2, grad_w3, grad_w4, grad_b1, grad_b2, grad_b3, grad_b4,
                                         w1, w2, w3, w4);
            }

            // After each batch, update weights and biases
#pragma omp critical
            {
                update_weights(w1, grad_w1, learning_rate, batch_end - batch_start);
                update_weights(w2, grad_w2, learning_rate, batch_end - batch_start);
                update_weights(w3, grad_w3, learning_rate, batch_end - batch_start);
                update_weights(w4, grad_w4, learning_rate, batch_end - batch_start);
                update_bias(b1, grad_b1, learning_rate, batch_end - batch_start);
                update_bias(b2, grad_b2, learning_rate, batch_end - batch_start);
                update_bias(b3, grad_b3, learning_rate, batch_end - batch_start);
                update_bias(b4, grad_b4, learning_rate, batch_end - batch_start);
            }
        }

        auto training_end = high_resolution_clock::now();
        auto training_duration = duration_cast<milliseconds>(training_end - training_start).count();
        total_training_time += training_duration;

        double avg_loss = total_loss / train_images.size();
        std::cout << "Epoch " << epoch + 1 << " complete. Average Loss: " << avg_loss << std::endl;

        // Validation set evaluation
        double validation_accuracy = evaluate_accuracy(validation_images, validation_labels, w1, w2, w3, w4, b1, b2, b3, b4, hidden1_size, hidden2_size, hidden3_size, output_size);
        std::cout << "Validation accuracy: " << validation_accuracy * 100 << "%" << std::endl;

        auto epoch_end = high_resolution_clock::now();
        auto epoch_duration = duration_cast<milliseconds>(epoch_end - epoch_start).count();
        std::cout << "Epoch " << epoch + 1 << " took " << epoch_duration << " ms" << std::endl;
        total_epoch_time += epoch_duration;
        actual_epochs++;

        // Write results to file
        write_results_to_file(result_file, epoch + 1, avg_loss, validation_accuracy, epoch_duration, training_duration);

        // Early stopping check
        if (validation_accuracy > best_val_accuracy) {
            best_val_accuracy = validation_accuracy;
            patience_counter = 0;
        } else {
            patience_counter++;
        }

        if (patience_counter >= patience) {
            std::cout << "Early stopping triggered at epoch " << epoch + 1 << std::endl;
            break;
        }
    }

    // Total training time
    auto stop = high_resolution_clock::now();
    auto total_duration = duration_cast<milliseconds>(stop - start).count();
    std::cout << "Total training time: " << total_duration << " ms" << std::endl;

    if (actual_epochs > 0) {
        std::cout << "Average time per epoch: " << total_epoch_time / actual_epochs << " ms" << std::endl;
        std::cout << "Average training time per epoch: " << total_training_time / actual_epochs << " ms" << std::endl;
    }

    write_final_time_to_file(result_file, actual_epochs, total_duration, total_training_time, total_training_time / actual_epochs);

    // Test set evaluation
    auto test_start = high_resolution_clock::now();
    double test_loss = 0.0;
    int test_correct_count = 0;

#pragma omp parallel for reduction(+:test_loss, test_correct_count)
    for (int i = 0; i < test_images.size(); ++i) {
        std::vector<double> hidden1(hidden1_size), hidden2(hidden2_size), hidden3(hidden3_size), output(output_size);

        // Forward pass
        forward_pass(test_images[i], hidden1, hidden2, hidden3, output, w1, w2, w3, w4, b1, b2, b3, b4);

        // Compute loss
        double loss = compute_loss(output, test_labels[i]);
        test_loss += loss;

        // Calculate accuracy
        int predicted_label = std::distance(output.begin(), std::max_element(output.begin(), output.end()));
        int actual_label = std::distance(test_labels[i].begin(), std::max_element(test_labels[i].begin(), test_labels[i].end()));

        if (predicted_label == actual_label) {
            test_correct_count++;
        }
    }
    test_loss /= test_images.size();
    double test_accuracy = static_cast<double>(test_correct_count) / test_images.size();

    auto test_end = high_resolution_clock::now();
    auto test_duration = duration_cast<milliseconds>(test_end - test_start).count();

    std::cout << "Final Test average loss: " << test_loss << ", accuracy: " << test_accuracy * 100 << "%" << ", took " << test_duration << " ms" << std::endl;

    // Write test set evaluation to file
    std::ofstream file;
    file.open(result_file, std::ios::app);
    if (file.is_open()) {
        file << "Final Test average loss: " << test_loss << ", accuracy: " << test_accuracy * 100 << "%" << ", took " << test_duration << " ms" << std::endl;
        file.close();
    } else {
        std::cerr << "Failed to open file for writing test set evaluation." << std::endl;
    }

    return 0;

}
