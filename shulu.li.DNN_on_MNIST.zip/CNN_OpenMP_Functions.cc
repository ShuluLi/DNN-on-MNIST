#include "CNN_OpenMP_Functions.h"

// Read MNIST labels
void read_mnist_labels(const std::string& filepath, std::vector<std::vector<double>>& labels, int num_labels, int num_classes) {
    std::ifstream file(filepath, std::ios::binary);
    if (!file.is_open()) {
        std::cerr << "Could not open file: " << filepath << std::endl;
        exit(EXIT_FAILURE);
    }

    file.ignore(8);

    for (int i = 0; i < num_labels; ++i) {
        uint8_t label = 0;
        file.read(reinterpret_cast<char*>(&label), sizeof(label));

        std::vector<double> one_hot_label(num_classes, 0.0);
        one_hot_label[label] = 1.0;
        labels.push_back(one_hot_label);
    }
    file.close();
}

// Read MNIST images
void read_mnist_images(const std::string& filepath, std::vector<std::vector<double>>& images, int num_images, int image_size) {
    std::ifstream file(filepath, std::ios::binary);
    if (!file.is_open()) {
        std::cerr << "Could not open file: " << filepath << std::endl;
        exit(EXIT_FAILURE);
    }

    file.ignore(16);

    for (int i = 0; i < num_images; ++i) {
        std::vector<double> image(image_size);
        for (int j = 0; j < image_size; ++j) {
            uint8_t pixel = 0;
            file.read(reinterpret_cast<char*>(&pixel), sizeof(pixel));
            image[j] = static_cast<double>(pixel) / 255.0;
        }
        images.push_back(image);
    }
    file.close();
}

// Split the dataset into fixed training and validation sets
void split_train_val(const std::vector<std::vector<double>>& all_images,
                     const std::vector<std::vector<double>>& all_labels,
                     std::vector<std::vector<double>>& train_images,
                     std::vector<std::vector<double>>& train_labels,
                     std::vector<std::vector<double>>& val_images,
                     std::vector<std::vector<double>>& val_labels) {
    // Shuffle the data
    std::vector<int> indices(all_images.size());
    std::iota(indices.begin(), indices.end(), 0);
    std::random_device rd;
    std::mt19937 g(rd());
    std::shuffle(indices.begin(), indices.end(), g);

    // Split into validation and training sets, first 10,000 for validation, remaining 50,000 for training
    for (int i = 0; i < 10000; ++i) {
        val_images.push_back(all_images[indices[i]]);
        val_labels.push_back(all_labels[indices[i]]);
    }
    for (int i = 10000; i < 60000; ++i) {
        train_images.push_back(all_images[indices[i]]);
        train_labels.push_back(all_labels[indices[i]]);
    }
}

// ReLU activation function
inline double relu(double z) {
    return std::max(0.0, z);
}

// Derivative of ReLU
inline double relu_derivative(double z) {
    return z > 0 ? 1.0 : 0.0;
}

// Softmax activation function
std::vector<double> softmax(const std::vector<double>& z) {
    std::vector<double> result(z.size());
    double sum = 0.0;

#pragma omp parallel for reduction(+:sum)
    for (int i = 0; i < z.size(); ++i) {
        sum += exp(z[i]);
    }

#pragma omp parallel for
    for (int i = 0; i < z.size(); ++i) {
        result[i] = exp(z[i]) / sum;
    }

    return result;
}

// Cross-entropy loss function
double compute_loss(const std::vector<double>& output, const std::vector<double>& expected) {
    double loss = 0.0;
    const double epsilon = 1e-10;

#pragma omp parallel for reduction(+:loss)
    for (int i = 0; i < output.size(); ++i) {
        loss += -expected[i] * log(output[i] + epsilon);
    }
    return loss;
}

// Cross-entropy loss derivative function
std::vector<double> compute_loss_derivative(const std::vector<double>& output, const std::vector<double>& expected) {
    std::vector<double> derivative(output.size());

#pragma omp parallel for
    for (int i = 0; i < output.size(); ++i) {
        derivative[i] = output[i] - expected[i];
    }

    return derivative;
}

// Average pooling forward pass
std::vector<std::vector<std::vector<double>>> avg_pooling_forward(
        const std::vector<std::vector<std::vector<double>>>& input, int pool_size) {

int num_channels = static_cast<int>(input.size());
int height = static_cast<int>(input[0].size());
int width = static_cast<int>(input[0][0].size());

// Initialize output tensor
std::vector<std::vector<std::vector<double>>> output(
        num_channels, std::vector<std::vector<double>>(height / pool_size, std::vector<double>(width / pool_size)));

#pragma omp parallel for collapse(2)
for (int c = 0; c < num_channels; ++c) {
for (int i = 0; i < height; i += pool_size) {
for (int j = 0; j < width; j += pool_size) {
double sum_val = 0.0;
for (int ki = 0; ki < pool_size; ++ki) {
for (int kj = 0; kj < pool_size; ++kj) {
sum_val += input[c][i + ki][j + kj];
}
}
output[c][i / pool_size][j / pool_size] = sum_val / (pool_size * pool_size);
}
}
}

return output;
}

// Average pooling backward pass
std::vector<std::vector<std::vector<double>>> avg_pooling_backward(
        const std::vector<std::vector<std::vector<double>>>& input,
const std::vector<std::vector<std::vector<double>>>& d_output, int pool_size) {

int num_channels = static_cast<int>(input.size());
int height = static_cast<int>(input[0].size());
int width = static_cast<int>(input[0][0].size());

// Initialize gradient tensor
std::vector<std::vector<std::vector<double>>> d_input(
        num_channels, std::vector<std::vector<double>>(height, std::vector<double>(width, 0)));

#pragma omp parallel for collapse(2)
for (int c = 0; c < num_channels; ++c) {
for (int i = 0; i < height; i += pool_size) {
for (int j = 0; j < width; j += pool_size) {
double gradient = d_output[c][i / pool_size][j / pool_size] / (pool_size * pool_size);
for (int ki = 0; ki < pool_size; ++ki) {
for (int kj = 0; kj < pool_size; ++kj) {
d_input[c][i + ki][j + kj] = gradient;
}
}
}
}
}

return d_input;
}

// Rotate convolution kernel by 180°
std::vector<std::vector<double>> rotate180(const std::vector<std::vector<double>>& kernel) {
    int size = static_cast<int>(kernel.size());
    std::vector<std::vector<double>> rotated_kernel(size, std::vector<double>(size));

#pragma omp parallel for collapse(2)
    for (int i = 0; i < size; ++i) {
        for (int j = 0; j < size; ++j) {
            rotated_kernel[i][j] = kernel[size - 1 - i][size - 1 - j];
        }
    }

    return rotated_kernel;
}

// Convolutional layer forward pass
std::vector<std::vector<std::vector<double>>> conv2d_forward(
        const std::vector<std::vector<std::vector<double>>>& input,
const std::vector<std::vector<std::vector<std::vector<double>>>>& kernels,
const std::vector<double>& biases,
int stride, int padding) {

int num_kernels = static_cast<int>(kernels.size());
int num_channels = static_cast<int>(input.size());
int height = static_cast<int>(input[0].size());
int width = static_cast<int>(input[0][0].size());
int kernel_size = static_cast<int>(kernels[0][0].size());

// Calculate output dimensions
int output_height = (height - kernel_size + 2 * padding) / stride + 1;
int output_width = (width - kernel_size + 2 * padding) / stride + 1;

// Initialize output tensor
std::vector<std::vector<std::vector<double>>> output(
        num_kernels, std::vector<std::vector<double>>(output_height, std::vector<double>(output_width, 0.0)));

#pragma omp parallel for collapse(3)
for (int k = 0; k < num_kernels; ++k) {
for (int i = 0; i < output_height; ++i) {
for (int j = 0; j < output_width; ++j) {
double sum = biases[k];
for (int c = 0; c < num_channels; ++c) {
for (int ki = 0; ki < kernel_size; ++ki) {
for (int kj = 0; kj < kernel_size; ++kj) {
int ni = i * stride + ki - padding;
int nj = j * stride + kj - padding;
if (ni >= 0 && ni < height && nj >= 0 && nj < width) {
sum += input[c][ni][nj] * kernels[k][c][ki][kj];
}
}
}
}
output[k][i][j] = relu(sum);
}
}
}

return output;
}

// Convolutional layer backward pass
void conv2d_backward(const std::vector<std::vector<std::vector<double>>>& d_output,
const std::vector<std::vector<std::vector<double>>>& input,
const std::vector<std::vector<std::vector<std::vector<double>>>>& kernels,
std::vector<std::vector<std::vector<double>>>& d_input,
std::vector<std::vector<std::vector<std::vector<double>>>>& accumulated_d_kernels,
std::vector<double>& accumulated_d_biases,
int stride, int padding) {
int num_kernels = static_cast<int>(kernels.size());
int num_channels = static_cast<int>(input.size());
int input_height = static_cast<int>(input[0].size());
int input_width = static_cast<int>(input[0][0].size());
int kernel_size = static_cast<int>(kernels[0][0].size());
int output_height = static_cast<int>(d_output[0].size());
int output_width = static_cast<int>(d_output[0][0].size());

// Initialize gradient tensors
std::vector<std::vector<std::vector<std::vector<double>>>> d_kernels(num_kernels,std::vector<std::vector<std::vector<double>>>(num_channels,std::vector<std::vector<double>>(kernel_size, std::vector<double>(kernel_size, 0.0))));
std::vector<double> d_biases(num_kernels, 0.0);
d_input.assign(num_channels, std::vector<std::vector<double>>(input_height, std::vector<double>(input_width, 0.0)));

// Compute gradients for kernels, biases, and input
#pragma omp parallel for
for (int k = 0; k < num_kernels; ++k) {
for (int i = 0; i < output_height; ++i) {
for (int j = 0; j < output_width; ++j) {
#pragma omp atomic
d_biases[k] += d_output[k][i][j];
for (int c = 0; c < num_channels; ++c) {
for (int ki = 0; ki < kernel_size; ++ki) {
for (int kj = 0; kj < kernel_size; ++kj) {
int ni = i * stride + ki - padding;
int nj = j * stride + kj - padding;
if (ni >= 0 && ni < input_height && nj >= 0 && nj < input_width) {
#pragma omp atomic
d_kernels[k][c][ki][kj] += input[c][ni][nj] * d_output[k][i][j];
#pragma omp atomic
d_input[c][ni][nj] += rotate180(kernels[k][c])[ki][kj] * d_output[k][i][j] * relu_derivative(input[c][ni][nj]);
}
}
}
}
}
}
}


// Accumulate gradients
#pragma omp parallel for
for (int k = 0; k < num_kernels; ++k) {
for (int c = 0; c < num_channels; ++c) {
for (int ki = 0; ki < kernel_size; ++ki) {
for (int kj = 0; kj < kernel_size; ++kj) {
#pragma omp atomic
accumulated_d_kernels[k][c][ki][kj] += d_kernels[k][c][ki][kj];
}
}
}
#pragma omp atomic
accumulated_d_biases[k] += d_biases[k];
}
}

// Update convolutional layer parameters
void conv2d_update(std::vector<std::vector<std::vector<std::vector<double>>>>& kernels,
                   std::vector<std::vector<std::vector<std::vector<double>>>>& accumulated_d_kernels,
                   std::vector<double>& biases,
                   std::vector<double>& accumulated_d_biases,
                   double learning_rate_conv, int batch_size) {

// Update kernels using accumulated gradients
#pragma omp parallel for
for (int k = 0; k < kernels.size(); ++k) {
for (int c = 0; c < kernels[k].size(); ++c) {
for (int i = 0; i < kernels[k][c].size(); ++i) {
for (int j = 0; j < kernels[k][c][i].size(); ++j) {
kernels[k][c][i][j] -= learning_rate_conv * accumulated_d_kernels[k][c][i][j] / batch_size;
}
}
}
}

// Update biases using accumulated gradients
#pragma omp parallel for
for (int k = 0; k < biases.size(); ++k) {
biases[k] -= learning_rate_conv * accumulated_d_biases[k] / batch_size;
}

// Clear accumulated gradients for kernels
#pragma omp parallel for
for (int k = 0; k < accumulated_d_kernels.size(); ++k) {
for (int c = 0; c < accumulated_d_kernels[k].size(); ++c) {
for (int i = 0; i < accumulated_d_kernels[k][c].size(); ++i) {
std::fill(accumulated_d_kernels[k][c][i].begin(), accumulated_d_kernels[k][c][i].end(), 0.0);
}
}
}

// Clear accumulated gradients for biases
#pragma omp parallel for
for (int k = 0; k < accumulated_d_biases.size(); ++k) {
accumulated_d_biases[k] = 0.0;
}
}

// Fully connected layer forward pass
std::vector<double> fully_connected_forward(const std::vector<double>& input, const std::vector<std::vector<double>>& weights, const std::vector<double>& bias) {
    int output_size = static_cast<int>(weights[0].size());
    std::vector<double> output(output_size);

    // Compute the linear combination of inputs and weights, add biases
#pragma omp parallel for
    for (int i = 0; i < output_size; ++i) {
        output[i] = bias[i];
        for (int j = 0; j < input.size(); ++j) {
            output[i] += input[j] * weights[j][i];
        }
    }
    return output;
}

// Fully connected layer backward pass
void fully_connected_backward(const std::vector<double>& d_output, const std::vector<double>& input,
                              std::vector<std::vector<double>>& weights, std::vector<std::vector<double>>& accumulated_d_weights, std::vector<double>& accumulated_d_bias,
                              std::vector<double>& d_input) {
    int output_size = static_cast<int>(d_output.size());
    int input_size = static_cast<int>(input.size());

    // Calculate gradients with respect to inputs
#pragma omp parallel for
    for (int i = 0; i < input_size; ++i) {
        d_input[i] = 0;
        for (int j = 0; j < output_size; ++j) {
            d_input[i] += d_output[j] * weights[i][j];
        }
        d_input[i] *= relu_derivative(input[i]);
    }

    // Accumulate gradients for weights and biases
#pragma omp parallel for collapse(2)
    for (int i = 0; i < input_size; ++i) {
        for (int j = 0; j < output_size; ++j) {
            accumulated_d_weights[i][j] += input[i] * d_output[j];
        }
    }

#pragma omp parallel for
    for (int j = 0; j < output_size; ++j) {
        accumulated_d_bias[j] += d_output[j];
    }
}

// Fully connected layer parameter update
void fully_connected_update(std::vector<std::vector<double>>& weights, std::vector<double>& bias,
                            std::vector<std::vector<double>>& accumulated_d_weights, std::vector<double>& accumulated_d_bias,
                            double learning_rate_fc, int batch_size) {
    int output_size = static_cast<int>(bias.size());
    int input_size = static_cast<int>(weights.size());

    // Update weights and biases using accumulated gradients
#pragma omp parallel for collapse(2)
    for (int i = 0; i < input_size; ++i) {
        for (int j = 0; j < output_size; ++j) {
            weights[i][j] -= learning_rate_fc * accumulated_d_weights[i][j] / batch_size;
        }
    }

#pragma omp parallel for
    for (int j = 0; j < output_size; ++j) {
        bias[j] -= learning_rate_fc * accumulated_d_bias[j] / batch_size;
    }

    // Clear accumulated gradients
#pragma omp parallel for collapse(2)
    for (int i = 0; i < input_size; ++i) {
        for (int j = 0; j < output_size; ++j) {
            accumulated_d_weights[i][j] = 0.0;
        }
    }

#pragma omp parallel for
    for (int j = 0; j < output_size; ++j) {
        accumulated_d_bias[j] = 0.0;
    }
}

// Flatten convolutional layer
//std::vector<double> flatten_output(const std::vector<std::vector<std::vector<double>>>& conv_output) {
//    int depth = static_cast<int>(conv_output.size());
//    int height = static_cast<int>(conv_output[0].size());
//    int width = static_cast<int>(conv_output[0][0].size());
//
//    std::vector<double> flattened(depth * height * width);
//    for (int d = 0; d < depth; ++d) {
//        for (int h = 0; h < height; ++h) {
//            for (int w = 0; w < width; ++w) {
//                flattened[d * height * width + h * width + w] = conv_output[d][h][w];
//            }
//        }
//    }
//
//    return flattened;
//}

// Unflatten to convolutional layer
void unflatten_output(const std::vector<double>& flattened, std::vector<std::vector<std::vector<double>>>& output) {
int depth = static_cast<int>(output.size());
int height = static_cast<int>(output[0].size());
int width = static_cast<int>(output[0][0].size());

#pragma omp parallel for collapse(3)
for (int d = 0; d < depth; ++d) {
for (int h = 0; h < height; ++h) {
for (int w = 0; w < width; ++w) {
output[d][h][w] = flattened[d * height * width + h * width + w];
}
}
}
}

//// He Initialization
//double he_initialization(int fan_in) {
//    std::default_random_engine generator;
//    std::normal_distribution<double> distribution(0.0, sqrt(2.0 / fan_in));
//    return distribution(generator);
//}

// Write results to file
void write_results_to_file(const std::string& filepath, int epoch, double avg_loss, double val_acc, long long epoch_time, long long training_time) {
    std::ofstream file;
    file.open(filepath, std::ios::app);
    if (file.is_open()) {
        file << "Epoch: " << epoch << " Average Loss: " << avg_loss << " Validation Accuracy: " << val_acc * 100 << "% Total Epoch Time: "
             << epoch_time << " ms Training Time: " << training_time << " ms" << std::endl;
        file.close();
    } else {
        std::cerr << "Failed to open file for writing results." << std::endl;
    }
}

