#ifndef CNN_OPENMP_FUNCTIONS_H
#define CNN_OPENMP_FUNCTIONS_H

#include <iostream>
#include <random>
#include <vector>
#include <cmath>
#include <fstream>
#include <cstdint>
#include <cassert>
#include <algorithm>
#include <numeric>
#include <chrono>
#include <omp.h>

// Read MNIST labels
void read_mnist_labels(const std::string& filepath, std::vector<std::vector<double>>& labels, int num_labels, int num_classes);

// Read MNIST images
void read_mnist_images(const std::string& filepath, std::vector<std::vector<double>>& images, int num_images, int image_size);

// Split the dataset into fixed training and validation sets
void split_train_val(const std::vector<std::vector<double>>& all_images,
                     const std::vector<std::vector<double>>& all_labels,
                     std::vector<std::vector<double>>& train_images,
                     std::vector<std::vector<double>>& train_labels,
                     std::vector<std::vector<double>>& val_images,
                     std::vector<std::vector<double>>& val_labels);

// ReLU activation function
inline double relu(double z);

// Derivative of ReLU
inline double relu_derivative(double z);

// Softmax activation function
std::vector<double> softmax(const std::vector<double>& z);

// Cross-entropy loss function
double compute_loss(const std::vector<double>& output, const std::vector<double>& expected);

// Cross-entropy loss derivative function
std::vector<double> compute_loss_derivative(const std::vector<double>& output, const std::vector<double>& expected);

// Average pooling forward pass
std::vector<std::vector<std::vector<double>>> avg_pooling_forward(
        const std::vector<std::vector<std::vector<double>>>& input, int pool_size);

// Average pooling backward pass
std::vector<std::vector<std::vector<double>>> avg_pooling_backward(
        const std::vector<std::vector<std::vector<double>>>& input,
const std::vector<std::vector<std::vector<double>>>& d_output, int pool_size);

// Rotate convolution kernel by 180°
std::vector<std::vector<double>> rotate180(const std::vector<std::vector<double>>& kernel);

// Convolutional layer forward pass
std::vector<std::vector<std::vector<double>>> conv2d_forward(
        const std::vector<std::vector<std::vector<double>>>& input,
const std::vector<std::vector<std::vector<std::vector<double>>>>& kernels,
const std::vector<double>& biases,
int stride, int padding);

// Convolutional layer backward pass
void conv2d_backward(const std::vector<std::vector<std::vector<double>>>& d_output,
const std::vector<std::vector<std::vector<double>>>& input,
const std::vector<std::vector<std::vector<std::vector<double>>>>& kernels,
std::vector<std::vector<std::vector<double>>>& d_input,
std::vector<std::vector<std::vector<std::vector<double>>>>& accumulated_d_kernels,
std::vector<double>& accumulated_d_biases,
int stride, int padding);

// Update convolutional layer parameters
void conv2d_update(std::vector<std::vector<std::vector<std::vector<double>>>>& kernels,
                   std::vector<std::vector<std::vector<std::vector<double>>>>& accumulated_d_kernels,
                   std::vector<double>& biases,
                   std::vector<double>& accumulated_d_biases,
                   double learning_rate_conv, int batch_size);

// Fully connected layer forward pass
std::vector<double> fully_connected_forward(const std::vector<double>& input, const std::vector<std::vector<double>>& weights, const std::vector<double>& bias);

// Fully connected layer backward pass
void fully_connected_backward(const std::vector<double>& d_output, const std::vector<double>& input,
                              std::vector<std::vector<double>>& weights, std::vector<std::vector<double>>& accumulated_d_weights,
                              std::vector<double>& accumulated_d_bias, std::vector<double>& d_input);

// Fully connected layer parameter update
void fully_connected_update(std::vector<std::vector<double>>& weights, std::vector<double>& bias,
                            std::vector<std::vector<double>>& accumulated_d_weights, std::vector<double>& accumulated_d_bias,
                            double learning_rate_fc, int batch_size);

// Unflatten to convolutional layer
void unflatten_output(const std::vector<double>& flattened, std::vector<std::vector<std::vector<double>>>& output);

// Write results to file
void write_results_to_file(const std::string& filepath, int epoch, double avg_loss, double val_acc, long long epoch_time, long long training_time);


#endif //CNN_OPENMP_FUNCTIONS_H
