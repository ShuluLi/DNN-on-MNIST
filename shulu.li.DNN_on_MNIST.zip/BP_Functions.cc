#include "BP_Functions.h"

// Read MNIST labels
void read_mnist_labels(const std::string& filepath, std::vector<std::vector<double>>& labels, int num_labels, int num_classes) {
    std::ifstream file(filepath, std::ios::binary);
    if (!file.is_open()) {
        std::cerr << "Could not open file: " << filepath << std::endl;
        exit(EXIT_FAILURE);
    }

    file.ignore(8);

    for (int i = 0; i < num_labels; ++i) {
        uint8_t label = 0;
        file.read(reinterpret_cast<char*>(&label), sizeof(label));

        std::vector<double> one_hot_label(num_classes, 0.0);
        one_hot_label[label] = 1.0;
        labels.push_back(one_hot_label);
    }
    file.close();
}

// Read MNIST images
void read_mnist_images(const std::string& filepath, std::vector<std::vector<double>>& images, int num_images, int image_size) {
    std::ifstream file(filepath, std::ios::binary);
    if (!file.is_open()) {
        std::cerr << "Could not open file: " << filepath << std::endl;
        exit(EXIT_FAILURE);
    }

    file.ignore(16);

    for (int i = 0; i < num_images; ++i) {
        std::vector<double> image(image_size);
        for (int j = 0; j < image_size; ++j) {
            uint8_t pixel = 0;
            file.read(reinterpret_cast<char*>(&pixel), sizeof(pixel));
            image[j] = static_cast<double>(pixel) / 255.0;
        }
        images.push_back(image);
    }
    file.close();
}

// Get prediction label
int get_prediction(const std::vector<double>& output) {
    int predicted_label = 0;
    double max_value = output[0];
    for (int i = 1; i < output.size(); ++i) {
        if (output[i] > max_value) {
            max_value = output[i];
            predicted_label = i;
        }
    }
    return predicted_label;
}

// Split the dataset into fixed training and validation sets
void split_train_val(const std::vector<std::vector<double>>& all_images,
                     const std::vector<std::vector<double>>& all_labels,
                     std::vector<std::vector<double>>& train_images,
                     std::vector<std::vector<double>>& train_labels,
                     std::vector<std::vector<double>>& val_images,
                     std::vector<std::vector<double>>& val_labels) {
    // Shuffle the data
    std::vector<int> indices(all_images.size());
    std::iota(indices.begin(), indices.end(), 0);
    std::random_device rd;
    std::mt19937 g(rd());
    std::shuffle(indices.begin(), indices.end(), g);

    // Split into validation and training sets, first 10,000 for validation, remaining 50,000 for training
    for (int i = 0; i < 10000; ++i) {
        val_images.push_back(all_images[indices[i]]);
        val_labels.push_back(all_labels[indices[i]]);
    }
    for (int i = 10000; i < 60000; ++i) {
        train_images.push_back(all_images[indices[i]]);
        train_labels.push_back(all_labels[indices[i]]);
    }
}

// ReLU activation function
inline double relu(double z) {
    return std::max(0.0, z);
}

// Derivative of ReLU
inline double relu_derivative(double z) {
    return z > 0 ? 1.0 : 0.0;
}

// Softmax activation function
std::vector<double> softmax(const std::vector<double>& z) {
    std::vector<double> result(z.size());
    double sum = 0.0;

    for (double val : z) {
        sum += exp(val);
    }

    for (int i = 0; i < z.size(); ++i) {
        result[i] = exp(z[i]) / sum;
    }

    return result;
}

// Cross-entropy loss function
double compute_loss(const std::vector<double>& output, const std::vector<double>& expected) {
    double loss = 0.0;
    const double epsilon = 1e-10;
    for (int i = 0; i < output.size(); ++i) {
        loss += -expected[i] * log(output[i] + epsilon);
    }
    return loss;
}

// Initialize weights
//void initialize_weights(std::vector<std::vector<double>>& weights, int rows, int cols) {
//    for (int i = 0; i < rows; ++i) {
//        std::vector<double> row;
//        for (int j = 0; j < cols; ++j)
//            row.push_back((rand() % 100) / 100.0 - 0.5);  // [-0.5, 0.5]
//
//        weights.push_back(row);
//    }
//}
void initialize_weights(std::vector<std::vector<double>>& weights, int rows, int cols) {
    weights.resize(rows, std::vector<double>(cols));

    std::random_device rd;
    std::mt19937 generator(rd());
    std::normal_distribution<double> distribution(0.0, std::sqrt(2.0 / rows));

    for (int i = 0; i < rows; ++i) {
        for (int j = 0; j < cols; ++j) {
            weights[i][j] = distribution(generator);
        }
    }
}

// Initialize biases
//void initialize_bias(std::vector<double>& bias, int size) {
//    for (int i = 0; i < size; ++i) {
//        bias.push_back((rand() % 100) / 100.0 - 0.5);
//    }
//}
void initialize_bias(std::vector<double>& bias, int size) {
    bias = std::vector<double>(size, 0.0);
}

// Forward pass
void forward_pass(const std::vector<double>& input,
                  std::vector<double>& hidden1,
                  std::vector<double>& hidden2,
                  std::vector<double>& hidden3,
                  std::vector<double>& output,
                  const std::vector<std::vector<double>>& w1,
                  const std::vector<std::vector<double>>& w2,
                  const std::vector<std::vector<double>>& w3,
                  const std::vector<std::vector<double>>& w4,
                  const std::vector<double>& b1,
                  const std::vector<double>& b2,
                  const std::vector<double>& b3,
                  const std::vector<double>& b4) {
    // First hidden layer calculation
    for (int i = 0; i < hidden1.size(); ++i) {
        hidden1[i] = 0;
        for (int j = 0; j < input.size(); ++j) {
            hidden1[i] += input[j] * w1[j][i];
        }
        hidden1[i] += b1[i];
        hidden1[i] = relu(hidden1[i]);
    }

    // Second hidden layer calculation
    for (int i = 0; i < hidden2.size(); ++i) {
        hidden2[i] = 0;
        for (int j = 0; j < hidden1.size(); ++j) {
            hidden2[i] += hidden1[j] * w2[j][i];
        }
        hidden2[i] += b2[i];
        hidden2[i] = relu(hidden2[i]);
    }

    // Third hidden layer calculation
    for (int i = 0; i < hidden3.size(); ++i) {
        hidden3[i] = 0;
        for (int j = 0; j < hidden2.size(); ++j) {
            hidden3[i] += hidden2[j] * w3[j][i];
        }
        hidden3[i] += b3[i];
        hidden3[i] = relu(hidden3[i]);
    }

    // Output layer calculation
    for (int i = 0; i < output.size(); ++i) {
        output[i] = 0;
        for (int j = 0; j < hidden3.size(); ++j) {
            output[i] += hidden3[j] * w4[j][i];
        }
        output[i] += b4[i];
    }

    output = softmax(output);
}

//// Backward pass
//void backward_pass(const std::vector<double>& input,
//                   const std::vector<double>& hidden1,
//                   const std::vector<double>& hidden2,
//                   const std::vector<double>& hidden3,
//                   const std::vector<double>& output,
//                   const std::vector<double>& expected,
//                   std::vector<std::vector<double>>& w1,
//                   std::vector<std::vector<double>>& w2,
//                   std::vector<std::vector<double>>& w3,
//                   std::vector<std::vector<double>>& w4,
//                   std::vector<double>& b1,
//                   std::vector<double>& b2,
//                   std::vector<double>& b3,
//                   std::vector<double>& b4,
//                   double learning_rate) {
//    std::vector<double> output_delta(output.size());
//    std::vector<double> hidden3_delta(hidden3.size());
//    std::vector<double> hidden2_delta(hidden2.size());
//    std::vector<double> hidden1_delta(hidden1.size());
//
//    // Calculate error for output layer
//    for (int i = 0; i < output.size(); ++i) {
//        output_delta[i] = output[i] - expected[i];
//    }
//
//    // Calculate error for third hidden layer
//    for (int i = 0; i < hidden3.size(); ++i) {
//        hidden3_delta[i] = 0;
//        for (int j = 0; j < output.size(); ++j) {
//            hidden3_delta[i] += output_delta[j] * w4[i][j];
//        }
//        hidden3_delta[i] *= relu_derivative(hidden3[i]);
//    }
//
//    // Calculate error for second hidden layer
//    for (int i = 0; i < hidden2.size(); ++i) {
//        hidden2_delta[i] = 0;
//        for (int j = 0; j < hidden3.size(); ++j) {
//            hidden2_delta[i] += hidden3_delta[j] * w3[i][j];
//        }
//        hidden2_delta[i] *= relu_derivative(hidden2[i]);
//    }
//
//    // Calculate error for first hidden layer
//    for (int i = 0; i < hidden1.size(); ++i) {
//        hidden1_delta[i] = 0;
//        for (int j = 0; j < hidden2.size(); ++j) {
//            hidden1_delta[i] += hidden2_delta[j] * w2[i][j];
//        }
//        hidden1_delta[i] *= relu_derivative(hidden1[i]);
//    }
//
//    // Update weights w4 and bias b4
//    for (int i = 0; i < hidden3.size(); ++i) {
//        for (int j = 0; j < output.size(); ++j) {
//            w4[i][j] -= learning_rate * output_delta[j] * hidden3[i];
//        }
//    }
//    for (int i = 0; i < output.size(); ++i) {
//        b4[i] -= learning_rate * output_delta[i];
//    }
//
//    // Update weights w3 and bias b3
//    for (int i = 0; i < hidden2.size(); ++i) {
//        for (int j = 0; j < hidden3.size(); ++j) {
//            w3[i][j] -= learning_rate * hidden3_delta[j] * hidden2[i];
//        }
//    }
//    for (int i = 0; i < hidden3.size(); ++i) {
//        b3[i] -= learning_rate * hidden3_delta[i];
//    }
//
//    // Update weights w2 and bias b2
//    for (int i = 0; i < hidden1.size(); ++i) {
//        for (int j = 0; j < hidden2.size(); ++j) {
//            w2[i][j] -= learning_rate * hidden2_delta[j] * hidden1[i];
//        }
//    }
//    for (int i = 0; i < hidden2.size(); ++i) {
//        b2[i] -= learning_rate * hidden2_delta[i];
//    }
//
//    // Update weights w1 and bias b1
//    for (int i = 0; i < input.size(); ++i) {
//        for (int j = 0; j < hidden1.size(); ++j) {
//            w1[i][j] -= learning_rate * hidden1_delta[j] * input[i];
//        }
//    }
//    for (int i = 0; i < hidden1.size(); ++i) {
//        b1[i] -= learning_rate * hidden1_delta[i];
//    }
//}

void backward_pass_accumulate(const std::vector<double>& input,
                              const std::vector<double>& hidden1,
                              const std::vector<double>& hidden2,
                              const std::vector<double>& hidden3,
                              const std::vector<double>& output,
                              const std::vector<double>& expected,
                              std::vector<std::vector<double>>& grad_w1,
                              std::vector<std::vector<double>>& grad_w2,
                              std::vector<std::vector<double>>& grad_w3,
                              std::vector<std::vector<double>>& grad_w4,
                              std::vector<double>& grad_b1,
                              std::vector<double>& grad_b2,
                              std::vector<double>& grad_b3,
                              std::vector<double>& grad_b4,
                              const std::vector<std::vector<double>>& w1,
                              const std::vector<std::vector<double>>& w2,
                              const std::vector<std::vector<double>>& w3,
                              const std::vector<std::vector<double>>& w4) {

    std::vector<double> output_delta(output.size());
    std::vector<double> hidden3_delta(hidden3.size());
    std::vector<double> hidden2_delta(hidden2.size());
    std::vector<double> hidden1_delta(hidden1.size());

    // Calculate error for the output layer
    for (int i = 0; i < output.size(); ++i) {
        output_delta[i] = output[i] - expected[i];
    }

    // Calculate error for the third hidden layer
    for (int i = 0; i < hidden3.size(); ++i) {
        hidden3_delta[i] = 0;
        for (int j = 0; j < output.size(); ++j) {
            hidden3_delta[i] += output_delta[j] * w4[i][j];
        }
        hidden3_delta[i] *= relu_derivative(hidden3[i]);
    }

    // Calculate error for the second hidden layer
    for (int i = 0; i < hidden2.size(); ++i) {
        hidden2_delta[i] = 0;
        for (int j = 0; j < hidden3.size(); ++j) {
            hidden2_delta[i] += hidden3_delta[j] * w3[i][j];
        }
        hidden2_delta[i] *= relu_derivative(hidden2[i]);
    }

    // Calculate error for the first hidden layer
    for (int i = 0; i < hidden1.size(); ++i) {
        hidden1_delta[i] = 0;
        for (int j = 0; j < hidden2.size(); ++j) {
            hidden1_delta[i] += hidden2_delta[j] * w2[i][j];
        }
        hidden1_delta[i] *= relu_derivative(hidden1[i]);
    }

    // Accumulate gradients for w4 and b4
    for (int i = 0; i < hidden3.size(); ++i) {
        for (int j = 0; j < output.size(); ++j) {
            grad_w4[i][j] += output_delta[j] * hidden3[i];
        }
    }
    for (int i = 0; i < output.size(); ++i) {
        grad_b4[i] += output_delta[i];
    }

    // Accumulate gradients for w3 and b3
    for (int i = 0; i < hidden2.size(); ++i) {
        for (int j = 0; j < hidden3.size(); ++j) {
            grad_w3[i][j] += hidden3_delta[j] * hidden2[i];
        }
    }
    for (int i = 0; i < hidden3.size(); ++i) {
        grad_b3[i] += hidden3_delta[i];
    }

    // Accumulate gradients for w2 and b2
    for (int i = 0; i < hidden1.size(); ++i) {
        for (int j = 0; j < hidden2.size(); ++j) {
            grad_w2[i][j] += hidden2_delta[j] * hidden1[i];
        }
    }
    for (int i = 0; i < hidden2.size(); ++i) {
        grad_b2[i] += hidden2_delta[i];
    }

    // Accumulate gradients for w1 and b1
    for (int i = 0; i < input.size(); ++i) {
        for (int j = 0; j < hidden1.size(); ++j) {
            grad_w1[i][j] += hidden1_delta[j] * input[i];
        }
    }
    for (int i = 0; i < hidden1.size(); ++i) {
        grad_b1[i] += hidden1_delta[i];
    }
}

// Update weights using accumulated gradients
void update_weights(std::vector<std::vector<double>>& weights,
                    const std::vector<std::vector<double>>& grad_weights,
                    double learning_rate, int batch_size) {
    for (int i = 0; i < weights.size(); ++i) {
        for (int j = 0; j < weights[i].size(); ++j) {
            weights[i][j] -= learning_rate * grad_weights[i][j] / batch_size;
        }
    }
}

// Update biases using accumulated gradients
void update_bias(std::vector<double>& bias,
                 const std::vector<double>& grad_bias,
                 double learning_rate, int batch_size) {
    for (int i = 0; i < bias.size(); ++i) {
        bias[i] -= learning_rate * grad_bias[i] / batch_size;
    }
}

// Calculate accuracy
double evaluate_accuracy(const std::vector<std::vector<double>>& data_images,
                         const std::vector<std::vector<double>>& data_labels,
                         const std::vector<std::vector<double>>& w1,
                         const std::vector<std::vector<double>>& w2,
                         const std::vector<std::vector<double>>& w3,
                         const std::vector<std::vector<double>>& w4,
                         const std::vector<double>& b1,
                         const std::vector<double>& b2,
                         const std::vector<double>& b3,
                         const std::vector<double>& b4,
                         int hidden1_size, int hidden2_size, int hidden3_size, int output_size) {
    int correct_predictions = 0;

    for (int i = 0; i < data_images.size(); ++i) {
        std::vector<double> hidden1(hidden1_size), hidden2(hidden2_size), hidden3(hidden3_size), output(output_size);

        // Forward pass
        forward_pass(data_images[i], hidden1, hidden2, hidden3, output, w1, w2, w3, w4, b1, b2, b3, b4);

        // Get predicted label
        int predicted_label = get_prediction(output);
        // Get actual label
        int actual_label = get_prediction(data_labels[i]);

        if (predicted_label == actual_label) {
            correct_predictions++;
        }
    }

    return (double)correct_predictions / data_images.size();
}

// Write results to file
void write_results_to_file(const std::string& filepath, int epoch, double avg_loss, double val_acc, long long epoch_time, long long training_time) {
    std::ofstream file;
    file.open(filepath, std::ios::app);
    if (file.is_open()) {
        file << "Epoch: " << epoch << " Average Loss: " << avg_loss << " Validation Accuracy: " << val_acc * 100 << "% Total Epoch Time: "
             << epoch_time << " ms Training Time: " << training_time << " ms" << std::endl;
        file.close();
    } else {
        std::cerr << "Failed to open file for writing results." << std::endl;
    }
}


// Write total and average time after training
void write_final_time_to_file(const std::string& filepath, int total_epochs, long long total_time, long long total_training_time, long long avg_training_time_per_epoch) {
    std::ofstream file;
    file.open(filepath, std::ios::app);
    if (file.is_open()) {
        file << "Total Epochs: " << total_epochs << " Total Time: " << total_time << " ms Average Time per Epoch: " << total_time / total_epochs << " ms" << std::endl;
        file << "Total Training Time: " << total_training_time << " ms Average Training Time per Epoch: " << avg_training_time_per_epoch << " ms" << std::endl;
        file.close();
    } else {
        std::cerr << "Failed to open file for writing final time." << std::endl;
    }
}
