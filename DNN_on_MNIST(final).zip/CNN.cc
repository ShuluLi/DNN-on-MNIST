#include "CNN_Functions.h"

int main() {
    using namespace std::chrono;

    // Data reading variables
    std::vector<std::vector<double>> all_images, all_labels;
    std::vector<std::vector<double>> train_images, train_labels;
    std::vector<std::vector<double>> val_images, val_labels;
    std::vector<std::vector<double>> test_images, test_labels;

    // Read data
    read_mnist_images("train-images.idx3-ubyte", all_images, 60000, 28 * 28);
    read_mnist_labels("train-labels.idx1-ubyte", all_labels, 60000, 10);
    read_mnist_images("t10k-images.idx3-ubyte", test_images, 10000, 28 * 28);
    read_mnist_labels("t10k-labels.idx1-ubyte", test_labels, 10000, 10);

    // Split the training and validation sets
    split_train_val(all_images, all_labels, train_images, train_labels, val_images, val_labels);

    // Initialize convolutional kernels and biases
    int kernel_size_1 = 5, kernel_size_2 = 5, kernel_size_3 = 4;
    std::vector<std::vector<std::vector<std::vector<double>>>> conv1_kernels(6, std::vector<std::vector<std::vector<double>>>(1, std::vector<std::vector<double>>(kernel_size_1, std::vector<double>(kernel_size_1))));
    std::vector<std::vector<std::vector<std::vector<double>>>> conv2_kernels(16, std::vector<std::vector<std::vector<double>>>(6, std::vector<std::vector<double>>(kernel_size_2, std::vector<double>(kernel_size_2))));
    std::vector<std::vector<std::vector<std::vector<double>>>> conv3_kernels(120, std::vector<std::vector<std::vector<double>>>(16, std::vector<std::vector<double>>(kernel_size_3, std::vector<double>(kernel_size_3))));
    std::vector<double> conv1_biases(6, 0.0);
    std::vector<double> conv2_biases(16, 0.0);
    std::vector<double> conv3_biases(120, 0.0);

    std::default_random_engine generator;
    std::normal_distribution<double> xavier_distribution(0.0, sqrt(1.0 / (kernel_size_1 * kernel_size_1)));

    // Initialization for convolutional kernels
    for (auto& kernel_set : conv1_kernels) {
        for (auto& kernel : kernel_set) {
            for (auto& row : kernel) {
                for (auto& val : row) {
                    val = xavier_distribution(generator);
                }
            }
        }
    }
    for (auto& kernel_set : conv2_kernels) {
        for (auto& kernel : kernel_set) {
            for (auto& row : kernel) {
                for (auto& val : row) {
                    val = xavier_distribution(generator);
                }
            }
        }
    }
    for (auto& kernel_set : conv3_kernels) {
        for (auto& kernel : kernel_set) {
            for (auto& row : kernel) {
                for (auto& val : row) {
                    val = xavier_distribution(generator);
                }
            }
        }
    }

    // Initialize fully connected layers
    std::vector<std::vector<double>> fc1_weights(120, std::vector<double>(84));
    std::vector<double> fc1_bias(84, 0);
    std::vector<std::vector<double>> fc2_weights(84, std::vector<double>(10));
    std::vector<double> fc2_bias(10, 0);

    // Initialization for fully connected layer weights
    for (auto& row : fc1_weights) {
        for (auto& val : row) {
            val = xavier_distribution(generator);
        }
    }
    for (auto& row : fc2_weights) {
        for (auto& val : row) {
            val = xavier_distribution(generator);
        }
    }

    // Parameters
    double learning_rate_conv_initial = 0.001;
    double learning_rate_fc_initial = 0.001;
    double learning_rate_conv = learning_rate_conv_initial;
    double learning_rate_fc = learning_rate_fc_initial;
    double decay_rate = 0.9;
    int batch_size = 20;
    int epochs = 100;

    // Early stopping parameters
    double best_val_accuracy = 0.0;
    int patience = 10;
    int patience_counter = 0;
    int actual_epochs = 0;

    // Initialize containers for accumulated gradients
    std::vector<std::vector<std::vector<std::vector<double>>>> accumulated_d_kernel1(6, std::vector<std::vector<std::vector<double>>>(1, std::vector<std::vector<double>>(kernel_size_1, std::vector<double>(kernel_size_1, 0.0))));
    std::vector<std::vector<std::vector<std::vector<double>>>> accumulated_d_kernel2(16, std::vector<std::vector<std::vector<double>>>(6, std::vector<std::vector<double>>(kernel_size_2, std::vector<double>(kernel_size_2, 0.0))));
    std::vector<std::vector<std::vector<std::vector<double>>>> accumulated_d_kernel3(120, std::vector<std::vector<std::vector<double>>>(16, std::vector<std::vector<double>>(kernel_size_3, std::vector<double>(kernel_size_3, 0.0))));
    std::vector<double> accumulated_d_bias1(6, 0.0);
    std::vector<double> accumulated_d_bias2(16, 0.0);
    std::vector<double> accumulated_d_bias3(120, 0.0);

    std::vector<std::vector<double>> accumulated_d_fc1_weights(120, std::vector<double>(84, 0.0));
    std::vector<double> accumulated_d_fc1_bias(84, 0.0);
    std::vector<std::vector<double>> accumulated_d_fc2_weights(84, std::vector<double>(10, 0.0));
    std::vector<double> accumulated_d_fc2_bias(10, 0.0);

    // Start timing
    long long total_training_time = 0;
    auto training_start_time = high_resolution_clock::now();

    // Training loop
    for (int epoch = 0; epoch < epochs; ++epoch) {
        actual_epochs++;
        auto epoch_start_time = high_resolution_clock::now();
        auto training_epoch_start_time = high_resolution_clock::now();

        // Decay learning rate every 10 epochs
        if (epoch % 10 == 0 && epoch != 0) {
            learning_rate_conv *= decay_rate;
            learning_rate_fc *= decay_rate;
        }

        // Training process
        for (int batch_start = 0; batch_start < train_images.size(); batch_start += batch_size) {
            int current_batch_size = std::min(batch_size, (int)train_images.size() - batch_start);

            // Train on the current batch
            for (int i = batch_start; i < batch_start + current_batch_size; ++i) {
                std::vector<std::vector<std::vector<double>>> input_image(1, std::vector<std::vector<double>>(28, std::vector<double>(28)));
                for (int row = 0; row < 28; ++row) {
                    for (int col = 0; col < 28; ++col) {
                        input_image[0][row][col] = train_images[i][row * 28 + col];
                    }
                }
                std::vector<double> target = train_labels[i];

                // Forward pass
                auto conv1_output = conv2d_forward(input_image, conv1_kernels, conv1_biases, 1, 0);
                auto pool1_output = avg_pooling_forward(conv1_output, 2);
                auto conv2_output = conv2d_forward(pool1_output, conv2_kernels, conv2_biases, 1, 0);
                auto pool2_output = avg_pooling_forward(conv2_output, 2);
                auto conv3_output = conv2d_forward(pool2_output, conv3_kernels, conv3_biases, 1, 0);

                // Flatten the output
                std::vector<double> flattened_input(conv3_output.size());
                for (int j = 0; j < conv3_output.size(); ++j) {
                    flattened_input[j] = conv3_output[j][0][0];
                }

                auto fc1_output = fully_connected_forward(flattened_input, fc1_weights, fc1_bias);
                for (auto& val : fc1_output)
                    val = relu(val);

                auto fc2_output = fully_connected_forward(fc1_output, fc2_weights, fc2_bias);
                auto final_output = softmax(fc2_output);

                auto d_loss = compute_loss_derivative(final_output, target);

                // Backward pass
                std::vector<double> d_fc1_output(84, 0.0);
                fully_connected_backward(d_loss, fc1_output, fc2_weights, accumulated_d_fc2_weights, accumulated_d_fc2_bias, d_fc1_output);

                std::vector<double> d_flattened_input(120, 0.0);
                fully_connected_backward(d_fc1_output, flattened_input, fc1_weights, accumulated_d_fc1_weights, accumulated_d_fc1_bias, d_flattened_input);

                std::vector<std::vector<std::vector<double>>> d_conv3_output(120, std::vector<std::vector<double>>(1, std::vector<double>(1)));
                unflatten_output(d_flattened_input, d_conv3_output);

                std::vector<std::vector<std::vector<std::vector<double>>>> d_kernel3;
                std::vector<double> d_biases3;
                std::vector<std::vector<std::vector<double>>> d_input_image3;
                conv2d_backward(d_conv3_output, pool2_output, conv3_kernels, d_input_image3, accumulated_d_kernel3, accumulated_d_bias3, 1, 0);

                auto d_pool2_output = avg_pooling_backward(pool2_output, d_input_image3, 2);

                std::vector<std::vector<std::vector<std::vector<double>>>> d_kernel2;
                std::vector<double> d_biases2;
                std::vector<std::vector<std::vector<double>>> d_input_image2;
                conv2d_backward(d_pool2_output, pool1_output, conv2_kernels, d_input_image2, accumulated_d_kernel2, accumulated_d_bias2, 1, 0);

                auto d_pool1_output = avg_pooling_backward(pool1_output, d_input_image2, 2);

                std::vector<std::vector<std::vector<std::vector<double>>>> d_kernel1;
                std::vector<double> d_biases1;
                std::vector<std::vector<std::vector<double>>> d_input_image1;
                conv2d_backward(d_pool1_output, input_image, conv1_kernels, d_input_image1, accumulated_d_kernel1, accumulated_d_bias1, 1, 0);
            }

            // Update parameters
            conv2d_update(conv1_kernels, accumulated_d_kernel1, conv1_biases, accumulated_d_bias1, learning_rate_conv, current_batch_size);
            conv2d_update(conv2_kernels, accumulated_d_kernel2, conv2_biases, accumulated_d_bias2, learning_rate_conv, current_batch_size);
            conv2d_update(conv3_kernels, accumulated_d_kernel3, conv3_biases, accumulated_d_bias3, learning_rate_conv, current_batch_size);

            fully_connected_update(fc1_weights, fc1_bias, accumulated_d_fc1_weights, accumulated_d_fc1_bias, learning_rate_fc, current_batch_size);
            fully_connected_update(fc2_weights, fc2_bias, accumulated_d_fc2_weights, accumulated_d_fc2_bias, learning_rate_fc, current_batch_size);
        }

        auto training_epoch_end_time = high_resolution_clock::now();
        auto training_epoch_duration = duration_cast<milliseconds>(training_epoch_end_time - training_epoch_start_time).count();
        total_training_time += training_epoch_duration;

        // Validation set evaluation
        double val_loss = 0.0;
        int val_correct_count = 0;
        for (int i = 0; i < val_images.size(); ++i) {
            std::vector<std::vector<std::vector<double>>> input_image(1, std::vector<std::vector<double>>(28, std::vector<double>(28)));
            for (int row = 0; row < 28; ++row) {
                for (int col = 0; col < 28; ++col) {
                    input_image[0][row][col] = val_images[i][row * 28 + col];
                }
            }

            auto conv1_output = conv2d_forward(input_image, conv1_kernels, conv1_biases, 1, 0);
            auto pool1_output = avg_pooling_forward(conv1_output, 2);
            auto conv2_output = conv2d_forward(pool1_output, conv2_kernels, conv2_biases, 1, 0);
            auto pool2_output = avg_pooling_forward(conv2_output, 2);
            auto conv3_output = conv2d_forward(pool2_output, conv3_kernels, conv3_biases, 1, 0);

            std::vector<double> flattened_input(conv3_output.size());
            for (int j = 0; j < conv3_output.size(); ++j) {
                flattened_input[j] = conv3_output[j][0][0];
            }

            auto fc1_output = fully_connected_forward(flattened_input, fc1_weights, fc1_bias);
            for (auto& val : fc1_output)
                val = relu(val);

            auto fc2_output = fully_connected_forward(fc1_output, fc2_weights, fc2_bias);
            auto final_output = softmax(fc2_output);

            val_loss += compute_loss(final_output, val_labels[i]);

            auto predicted_label = std::distance(final_output.begin(), std::max_element(final_output.begin(), final_output.end()));
            auto actual_label = std::distance(val_labels[i].begin(), std::max_element(val_labels[i].begin(), val_labels[i].end()));

            if (predicted_label == actual_label) {
                val_correct_count++;
            }
        }

        val_loss /= static_cast<double>(val_images.size());
        double val_accuracy = static_cast<double>(val_correct_count) / static_cast<double>(val_images.size());
        std::cout << "Epoch " << epoch + 1 << " complete. Average Loss: " << val_loss << " Validation accuracy: " << val_accuracy * 100.0 << "%" << std::endl;

        // Calculate the total time for each epoch
        auto epoch_end_time = high_resolution_clock::now();
        auto epoch_duration = duration_cast<milliseconds>(epoch_end_time - epoch_start_time).count();
        std::cout << "Epoch " << epoch + 1 << " complete. Epoch time: " << epoch_duration << " ms. Training time: " << training_epoch_duration << " ms." << std::endl;

        // Write results to file
        write_results_to_file("result_CNN.txt", epoch + 1, val_loss, val_accuracy, epoch_duration, training_epoch_duration);

        // Early stopping test
        if (val_accuracy > best_val_accuracy) {
            best_val_accuracy = val_accuracy;
            patience_counter = 0;
        } else {
            patience_counter++;
        }

        if (patience_counter >= patience) {
            std::cout << "Early stopping triggered at epoch " << epoch + 1 << std::endl;
            break;
        }
    }

    // Total training time
    auto training_end_time = high_resolution_clock::now();
    auto total_training_duration = duration_cast<milliseconds>(training_end_time - training_start_time).count();
    std::cout << "Total training time (including validation):: " << total_training_duration << " ms" << std::endl;

    // Write final training results to file
    std::ofstream file;
    file.open("result_CNN.txt", std::ios::app);
    if (file.is_open()) {
        file << "Total Epochs: " << actual_epochs
             << " Total Training Time (including validation): " << total_training_duration << " ms"
             << " Total Training-Only Time: " << total_training_time << " ms"
             << " Average Epoch Time: " << total_training_duration / actual_epochs << " ms"
             << " Average Training-Only Time per Epoch: " << total_training_time / actual_epochs << " ms" << std::endl;
        file.close();
    } else {
        std::cerr << "Failed to open file for writing final training results." << std::endl;
    }

    // Test set evaluation timing
    auto test_start_time = high_resolution_clock::now();

    double test_loss = 0.0;
    int test_correct_count = 0;
    for (int i = 0; i < test_images.size(); ++i) {
        std::vector<std::vector<std::vector<double>>> input_image(1, std::vector<std::vector<double>>(28, std::vector<double>(28)));
        for (int row = 0; row < 28; ++row) {
            for (int col = 0; col < 28; ++col) {
                input_image[0][row][col] = test_images[i][row * 28 + col];
            }
        }

        auto conv1_output = conv2d_forward(input_image, conv1_kernels, conv1_biases, 1, 0);
        auto pool1_output = avg_pooling_forward(conv1_output, 2);
        auto conv2_output = conv2d_forward(pool1_output, conv2_kernels, conv2_biases, 1, 0);
        auto pool2_output = avg_pooling_forward(conv2_output, 2);
        auto conv3_output = conv2d_forward(pool2_output, conv3_kernels, conv3_biases, 1, 0);

        std::vector<double> flattened_input(conv3_output.size());
        for (int j = 0; j < conv3_output.size(); ++j) {
            flattened_input[j] = conv3_output[j][0][0];
        }

        auto fc1_output = fully_connected_forward(flattened_input, fc1_weights, fc1_bias);
        for (auto& val : fc1_output)
            val = relu(val);

        auto fc2_output = fully_connected_forward(fc1_output, fc2_weights, fc2_bias);
        auto final_output = softmax(fc2_output);

        test_loss += compute_loss(final_output, test_labels[i]);

        int predicted_label = static_cast<int>(std::distance(final_output.begin(), std::max_element(final_output.begin(), final_output.end())));
        int actual_label = static_cast<int>(std::distance(test_labels[i].begin(), std::max_element(test_labels[i].begin(), test_labels[i].end())));

        if (predicted_label == actual_label) {
            test_correct_count++;
        }
    }

    test_loss /= static_cast<double>(test_images.size());
    double test_accuracy = static_cast<double>(test_correct_count) / static_cast<double>(test_images.size());
    auto test_end_time = high_resolution_clock::now();
    auto test_duration = duration_cast<milliseconds>(test_end_time - test_start_time).count();
    std::cout << "Final Test average loss: " << test_loss << ", accuracy: " << test_accuracy * 100.0 << "%" << ", took " << test_duration << " ms" << std::endl;

// Write test set evaluation results to file
    std::ofstream file1;
    file1.open("result_CNN.txt", std::ios::app);
    if (file1.is_open()) {
        file1 << "Final Test average loss: " << test_loss << ", accuracy: " << test_accuracy * 100.0 << "%, took " << test_duration << " ms" << std::endl;
        file1.close();
    } else {
        std::cerr << "Failed to open file for writing test set evaluation." << std::endl;
    }
}
