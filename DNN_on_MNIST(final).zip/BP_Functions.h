#ifndef BP_FUNCTIONS_H
#define BP_FUNCTIONS_H

#include <iostream>
#include <vector>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <cstdint>
#include <algorithm>
#include <random>
#include <chrono>

// Function declarations
void read_mnist_labels(const std::string& filepath, std::vector<std::vector<double>>& labels, int num_labels, int num_classes);
void read_mnist_images(const std::string& filepath, std::vector<std::vector<double>>& images, int num_images, int image_size);
int get_prediction(const std::vector<double>& output);
void split_train_val(const std::vector<std::vector<double>>& all_images,
                     const std::vector<std::vector<double>>& all_labels,
                     std::vector<std::vector<double>>& train_images,
                     std::vector<std::vector<double>>& train_labels,
                     std::vector<std::vector<double>>& val_images,
                     std::vector<std::vector<double>>& val_labels);
inline double relu(double z);
inline double relu_derivative(double z);
std::vector<double> softmax(const std::vector<double>& z);
double compute_loss(const std::vector<double>& output, const std::vector<double>& expected);
void initialize_weights(std::vector<std::vector<double>>& weights, int rows, int cols);
void initialize_bias(std::vector<double>& bias, int size);
void forward_pass(const std::vector<double>& input,
                  std::vector<double>& hidden1,
                  std::vector<double>& hidden2,
                  std::vector<double>& hidden3,
                  std::vector<double>& output,
                  const std::vector<std::vector<double>>& w1,
                  const std::vector<std::vector<double>>& w2,
                  const std::vector<std::vector<double>>& w3,
                  const std::vector<std::vector<double>>& w4,
                  const std::vector<double>& b1,
                  const std::vector<double>& b2,
                  const std::vector<double>& b3,
                  const std::vector<double>& b4);
void backward_pass_accumulate(const std::vector<double>& input,
                              const std::vector<double>& hidden1,
                              const std::vector<double>& hidden2,
                              const std::vector<double>& hidden3,
                              const std::vector<double>& output,
                              const std::vector<double>& expected,
                              std::vector<std::vector<double>>& grad_w1,
                              std::vector<std::vector<double>>& grad_w2,
                              std::vector<std::vector<double>>& grad_w3,
                              std::vector<std::vector<double>>& grad_w4,
                              std::vector<double>& grad_b1,
                              std::vector<double>& grad_b2,
                              std::vector<double>& grad_b3,
                              std::vector<double>& grad_b4,
                              const std::vector<std::vector<double>>& w1,
                              const std::vector<std::vector<double>>& w2,
                              const std::vector<std::vector<double>>& w3,
                              const std::vector<std::vector<double>>& w4);
void update_weights(std::vector<std::vector<double>>& weights,
                    const std::vector<std::vector<double>>& grad_weights,
                    double learning_rate, int batch_size);
void update_bias(std::vector<double>& bias,
                 const std::vector<double>& grad_bias,
                 double learning_rate, int batch_size);
double evaluate_accuracy(const std::vector<std::vector<double>>& data_images,
                         const std::vector<std::vector<double>>& data_labels,
                         const std::vector<std::vector<double>>& w1,
                         const std::vector<std::vector<double>>& w2,
                         const std::vector<std::vector<double>>& w3,
                         const std::vector<std::vector<double>>& w4,
                         const std::vector<double>& b1,
                         const std::vector<double>& b2,
                         const std::vector<double>& b3,
                         const std::vector<double>& b4,
                         int hidden1_size, int hidden2_size, int hidden3_size, int output_size);
void write_results_to_file(const std::string& filepath, int epoch, double avg_loss, double val_acc, long long epoch_time, long long training_time) ;
void write_final_time_to_file(const std::string& filepath, int total_epochs, long long total_time, long long total_training_time, long long avg_training_time_per_epoch) ;

#endif // BP_FUNCTIONS_H
